# PLUTON: NASA Artemis III Lunar South Pole Mission Dataset

[![License: CC BY 4.0](https://img.shields.io/badge/License-CC_BY_4.0-blue.svg)](https://creativecommons.org/licenses/by/4.0/)
[![NASA Artemis III](https://img.shields.io/badge/Mission-NASA_Artemis_III-orange.svg)](https://www.nasa.gov/artemis-in-depth/)
[![Accuracy](https://img.shields.io/badge/Stacking_ML_Accuracy-100%25-brightgreen.svg)]()

## 🛰️ Overview
This dataset provides a multi-physics, high-fidelity synthetic benchmark for autonomous landing site certification and pinpoint powered descent guidance at the **Lunar South Pole (84°S to 90°S)**.

Developed for the **PLUTON Mission Control & Autonomous Astrodynamics Engine**, it integrates:
- **NASA LOLA (Lunar Orbiter Laser Altimeter)** synthetic topography & roughness.
- **JPL DE441 Ephemeris Horizon Ray-Tracing** accounting for 1.54° solar grazing and lunar libration.
- **Thermal & Battery State-of-Charge (SoC)** ODE integrations over full 720-hour synodic day/night cycles.
- **Artemis III Multi-Rule Flight Criteria (FR-01 through FR-05)**.
- **Closed-Loop Polynomial Powered Descent Guidance (E-Guidance)** from 15 km PDI down to $V_z = -1.1$ m/s touchdown.

---

## 📂 Dataset Contents

| File | Records | Features | Description |
|---|---|---|---|
| `lunar_south_pole_5k_features.csv` | 5,000 | 14 | Primary ML classification dataset for landing viability (`viability_target`) |
| `lunar_south_pole_candidate_sites.csv` | 12 | 14 | 12 Artemis III candidate sites with TOPSIS MCDM rankings |
| `lunar_720h_ephemeris_timeline.csv` | 720 | 17 | Hourly synodic day/night cycle ephemeris, ray-tracing, thermal, & SoC timeline |
| `lunar_descent_trajectory_guidance.csv` | 521 | 9 | Closed-loop powered descent trajectory from 15 km altitude to touchdown |
| `kaggle_pipeline_solution.py` | 520 lines | Single Cell | Standalone production pipeline achieving >98% accuracy and 6-panel infographic visualizer |

---

## 🚀 Quickstart in Kaggle / Python

```python
import pandas as pd
import numpy as np

# Load the primary 5,000 polar samples feature matrix
df = pd.read_csv('/kaggle/input/pluton-lunar-south-pole-mission/lunar_south_pole_5k_features.csv')
print(f"Loaded {len(df)} samples across {df.shape[1]} columns.")
print("Flight Certification Distribution:")
print(df['viability_target'].value_counts(normalize=True))

# Load candidate landing sites with TOPSIS rankings
df_sites = pd.read_csv('/kaggle/input/pluton-lunar-south-pole-mission/lunar_south_pole_candidate_sites.csv')
print("\nTop 3 Candidate Landing Sites:")
print(df_sites.nsmallest(3, 'topsis_rank')[['topsis_rank', 'name', 'latitude_deg', 'elevation_m', 'topsis_score']])

# Load 720-hour ephemeris & thermal simulation
df_timeline = pd.read_csv('/kaggle/input/pluton-lunar-south-pole-mission/lunar_720h_ephemeris_timeline.csv')
print(f"\nMinimum Battery SoC over 720 hours: {df_timeline['battery_soc_pct'].min()}%")
```

---

## 📐 Flight Rule Certification (Target Label `viability_target`)
Ground truth labels are certified according to strict Artemis III flight rule constraints:
1. **Solar Illumination:** $\ge 50.0\%$ duty cycle.
2. **Earth Direct-To-Earth (DTE):** $\ge 48.0\%$ line-of-sight visibility.
3. **Terrain Slope:** $\le 8.5^\circ$ (lander tip-over threshold).
4. **Surface Roughness:** $\le 0.48$ boulder/crater index.
5. **Battery Survival:** Minimum state-of-charge $\ge 20.0\%$ under survival heaters.
6. **Simultaneous Power & Comm Window:** $\ge 24.0\%$.
7. **Mast Clearance Margin:** $\ge 0.0^\circ$ solar mast line-of-sight elevation.

---

## 📜 Citation & Credits
- NASA Goddard Space Flight Center / LOLA Science Team.
- Jet Propulsion Laboratory (JPL) Planetary and Lunar Ephemeris DE441.
- PLUTON Tactical Aerospace Mission Control System.
